/*
*malha.c
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "mpi.h"

int main(int argc,char **argv)
{
 int i,j,x,u,w,y,m2,*nu_elem,rest,dispf,iteracoes;
 double inicio,fim;

 float *aux,*h,*x_novo,*x_antigo,**N;
 float  *erros;
 float max[1];
 int eu,np,condicao,stop,cont,*disp;
 long int indexG, indexBufNum, index01, index02, rol, col, k;
 long int buffPointer;
 char bufferLine[16*512+4+1];
 char buffNumber[20];
 FILE *input,*output,*hOutput;


//Inicio do programa paralelo

   MPI_Init(&argc,&argv);
    MPI_Comm_size(MPI_COMM_WORLD,&np);
    MPI_Comm_rank(MPI_COMM_WORLD,&eu);

    if(argc!=2)
    {
		printf("Uso:./nomedoprograma dimensao\n");
		MPI_Finalize();
		exit(1);
	}

    else
    {
     condicao=0;
     x=atoi(argv[1]);
     y=x*x;
    }


 /*************/
    nu_elem =(int*)malloc(sizeof (int)*np);
    disp=(int *)malloc(sizeof(int)*np);
   // g=(float *)malloc(sizeof(float)*y);
    x_novo=(float *)malloc(sizeof(float)*y);
    x_antigo=(float *)malloc(sizeof(float)*y);
    erros=(float *)malloc(sizeof(float)*np);
/********************************/



if((eu==0)&&(condicao==0))
    { //01
    /* Distribuindo as linhas para os np processadores*/

     rest = y % np;
     for(i=0;i<np;i++)
         nu_elem[i]=y/np;
     if (rest)
        {
         while(rest--)
         {
          nu_elem[i-1]++;
          i--;
         }
        }
     //Comunico essa distribuicao para os demais processadores

     MPI_Bcast(nu_elem,np,MPI_INT,0,MPI_COMM_WORLD);
    } //!01

    else if(condicao==0)

    {
		MPI_Bcast(nu_elem,np,MPI_INT,0,MPI_COMM_WORLD);
	}

/*********************************/

/* Aloco matrizes*/

    aux =(float *)malloc(sizeof(float)*nu_elem[eu]);
  //  aux2 =(float *)malloc(sizeof(float)*nu_elem[eu]);
   // aux1 =(float *)malloc(sizeof(float)*nu_elem[eu]);


	h=(float*)malloc(sizeof(float)*nu_elem[eu]);


/*    if ((N=(float**)malloc(y*sizeof(float*)))==NULL)
			{
				printf("Erro alocando linas da matriz N.\n");
				MPI_Finalize();
				exit(1);//fecha MPI e desloca otras mem.
			}
			for (index01=0; index01<y; index01++)
			{
				if ((N[index01]=(float*)malloc(y*sizeof(float)))==NULL)
				{
					printf("Erro alocando colunas da matriz N.\n");
					MPI_Finalize();
					exit(1);//fecha MPI e desloca otras mem.
				}
	}*/

if ((N=(float**)malloc(nu_elem[eu]*sizeof(float*)))==NULL)
    			{
    				printf("Erro alocando linas da matriz N.\n");
    				MPI_Finalize();
    				exit(1);//fecha MPI e desloca otras mem.
    			}
    			for (index01=0; index01<nu_elem[eu]; index01++)
    			{
    				if ((N[index01]=(float*)malloc(y*sizeof(float)))==NULL)
    				{

    				printf("Erro alocando colunas da matriz N.\n");
    				MPI_Finalize();
    					exit(1);//fecha MPI e desloca otras mem.
    				}
    	}


/*fim*/

   /**************************************/

//Determino a linha inicio e fim do bloco que cada processador vai calcular

    disp[0]=0;
    for (i=1;i<np;i++)
    {
        disp[i] = disp[i-1] + nu_elem[i-1];
    }
    dispf=disp[eu]+nu_elem[eu];

    //printf("sou: %d, tenho: %d, %d, %d\n",eu,nu_elem[eu],disp[eu],dispf);





//indexG=0;
 	if(eu==0)
 	{
		indexG=0;
 //------abrindo o arquivo gImageFile----
 	if ((input=fopen("gImageFile","r"))==NULL)
 	{
 		printf("Arquivo gImageFile n�o existe.\n");
 		exit(1);
 	}

 	//------leitura do arquivo gImageFile e armazenamento no vetor g//

         for (rol=0; rol<x; rol++)
 	{
         buffPointer=0;
 		fgets(bufferLine,(10*x+4),input);
 		if (bufferLine[sizeof(bufferLine)]=='\n')
 			bufferLine[sizeof(bufferLine)]='\0';
         buffPointer=0;
         for (col=0;col<x;col++)
         {
         	while(bufferLine[buffPointer]==' ')
           		buffPointer++;
         	indexBufNum=0;
         	while((bufferLine[buffPointer]!=' ')&&(bufferLine[buffPointer]!='\0')&&(bufferLine[buffPointer]!='\n'))
         	{
         	       	buffNumber[indexBufNum]=bufferLine[buffPointer];
         	        buffPointer++;
         	        indexBufNum++;

 			}
 			buffNumber[indexBufNum]='\0';
 			x_antigo[indexG++]=atof(buffNumber);
 			buffPointer++;
 		}

 	}

 //	printf("Numero de elementos de g: %li\n",indexG);
 //MPI_Bcast(g,y,MPI_FLOAT,0,MPI_COMM_WORLD);
	} //if eu==0
	//else
	//MPI_Bcast(g,y,MPI_FLOAT,0,MPI_COMM_WORLD);

 	//--------fim leitura do arquivo gimageFile e armazenamento no vetor g//

	//--------distribuo o vetor g particionado para os demais processadores--------//

for (j=0;j<nu_elem[eu];j++)
	      h[j]=0;



	MPI_Scatterv(x_antigo,nu_elem,disp,MPI_FLOAT,h,nu_elem[eu],MPI_FLOAT,0,MPI_COMM_WORLD);

	 	//--------fim distribuicao --------//




/*	 for(i=disp[eu];i<dispf;i++)
	 {
	   if (i<(y-10))
	   {
	 		N[i][i+10]=-0.1;

	 		if(i>9)
	 		N[i][i-10]=-0.1;
	 		//N[i+10][i]=-0.1;
	   }

	 }
*/
for(i=disp[eu];i<dispf;i++)
	 {
	   if (i<(y-6))
	   {
	 		N[i-disp[eu]][i+7]=-0.5;

	 		if(i>6)
	 		N[i-disp[eu]][i-7]=-0.5;

	   }

	 }


 //Atribuicao de valores quaisquer
for (i=0;i<y;i++)
      {
	   x_antigo[i]=0.000000;
       x_novo[i]=0.755000;
      }
 stop=0;


//printf("Vou entrar no loop\n");

	     stop=0;


	     inicio=MPI_Wtime();
	     iteracoes=0;

	     while((iteracoes<500)&&(stop==0))
	     { //03

	      //iteracoes++;

	      for (i=0;i<y;i++)
	      {
	 		 x_antigo[i]=x_novo[i];
	 		 x_novo[i]=0;
	 	  }

	      for (j=0;j<nu_elem[eu];j++)
	      aux[j]=0;           //aux=0


	     for (i=disp[eu];i<dispf;i++)
	      {
	 		 for (j=0;j<y;j++)
	 	      aux[i-disp[eu]]+=N[i-disp[eu]][j]*x_antigo[j];

	 	     aux[i-disp[eu]]+=h[i-disp[eu]];
		  }



	      /**********/

	      MPI_Allgatherv(aux,nu_elem[eu],MPI_FLOAT,x_novo,nu_elem,disp,MPI_FLOAT,MPI_COMM_WORLD);



	        {//04

	         /***********************************/
	 		  for (j=0;j<nu_elem[eu];j++)
	 			 aux[j]=0;          //aux2=0



	 /***********************************/
	          for(i=disp[eu];i<dispf;i++)
				{

				aux[i-disp[eu]]=fabsf(x_novo[i]-x_antigo[i]);

			   }



	            max[0]=0;

	     for(i=0;i<nu_elem[eu];i++)

	        if(aux[i]>max[0])
	          max[0]=aux[i];     //max:norma infinita parcial



	     MPI_Gather(max,1,MPI_FLOAT,erros,1,MPI_FLOAT,0,MPI_COMM_WORLD);



	          if(eu==0) //calculando erro
	         {
	           max[0]=0;
	           for(i=0;i<np;i++)
	           {

	             if(erros[i]>max[0])
	               max[0]=erros[i];  //max:norma infinita total

			   }


	           if (max[0]<0.01)
	           stop=1;

	          } // fim calculo erro

	          MPI_Bcast(&stop,1,MPI_INT,0,MPI_COMM_WORLD);  //todo mundo recebe stop
	        }//!04

			iteracoes++;

	     } //!03
	     fim=MPI_Wtime();
	 //----------------------------------------------------------------------------

//	printf("iteracoes:%d\n",iteracoes);
	  if(eu==0)
	    { //05

	   printf("erro= %2.15f, iteracoes= %d, tempo= %.4f\n\n",max[0],iteracoes,fim-inicio);



	  if ((output=fopen("imageFile","w"))==NULL)
	  	{
	  		printf("Arquivo imageFile n�o foi criado.\n");
	  		exit(1);
	  	}

	  //------rearranjo da matriz f2-------
	  	//printf("f2[4900]=%f\n",f2[4899]);

	  	for (index01=0;index01<x;index01++)
	  	{
	  		for (index02=0;index02<x;index02++)
	  		{
	  			fprintf(output,"%f  ", x_novo[index01*x+index02]);
	  		}
	  		fprintf(output,"\n");
	  	}

       fclose(output);

	   fclose(input);

	    } //!05

	 //if(eu==0)
	 //{
	 //for(i=0;i<y;i++)
	 //   for(j=0;j<y;j++)
	    //printf("b[i][j]=%f\n", N[i][j]);
	  //  printf("sou: %d, tenho: %d, %d, %d\n",eu,nu_elem[eu],disp[eu],dispf);
	 //}
	    free(disp);
	    free(nu_elem);
	   // free(g);
	    free(h);
	    free(x_antigo);
	    free(x_novo);
	    free(aux);
	  //  free(aux2);
	   // free(aux1);
	    free(N);
	    //free(D);
	    free(erros);
	   // fclose(input);
	   //fclose(output);
	    MPI_Finalize();
	    exit(0);
	 }  /*main*/















